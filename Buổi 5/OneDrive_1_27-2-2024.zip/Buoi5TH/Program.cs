﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Buoi5TH
{
    internal class Program
    {
        static void Main(string[] args)
        {
            //======================================================================
            // Câu 1: Tìm các đỉnh liên thông với đỉnh x
            //AdjList newList = new AdjList();
            //newList.FileToAdjList(@"../../TextFile/AdjList.txt");
            //Console.Write("Enter starting vertex: ");
            //int x = int.Parse(Console.ReadLine());
            //Console.Write("Cac dinh lien thong voi " + x + ": ");
            //newList._DFS(x);
            //Console.ReadKey();
            //======================================================================
            ////Câu 2: Tìm đường đi từ X tới Y
            //AdjList newList = new AdjList();
            //newList.FileToAdjList(@"../../TextFile/AdjList.txt");
            //Console.Write("Enter starting vertex: ");
            //int x = int.Parse(Console.ReadLine());
            //Console.Write("Enter ending vertex: ");
            //int y = int.Parse(Console.ReadLine());
            //newList.DFSfromXtoY(x, y);
            //Console.ReadKey();
            //======================================================================
            // Câu 3: Xét tính liên thông của đồ thị, nếu đồ thị không liên thông thì cho biết đồ thị có bao nhiêu thành phần liên thông (TPLT) và xuất các thành phần liên thông lên màn hình
            //AdjList newList = new AdjList();
            //newList.FileToAdjList(@"../../TextFile/AdjList2.txt");
            //newList.Connected();
            //Console.WriteLine("Đồ thị có {0} miền liên thông", newList.Inconnect);
            //newList.OutConnected();
            //Console.ReadKey();
        }
    }
}
